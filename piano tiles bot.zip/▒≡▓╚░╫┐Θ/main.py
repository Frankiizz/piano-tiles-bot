import time

import keyboard
import pyautogui
import win32con, win32api

def click(x, y):
	win32api.SetCursorPos((x,y))
	win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)
	time.sleep(0.01)
	win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)


# number in click() and .pixel depends on where you want to detect color.
# each if statement represent one colum of the game.
# press'q'to end.
# ...pixel(x, y)[0] == 0: the first zero represent R in RGB.
# And the second zero represent black.
while keyboard.is_pressed('q') == False:
	if pyautogui.pixel(200, 700)[0] == 0:
		click(200, 700)
	elif pyautogui.pixel(280, 700)[0] == 0:
		click(280, 700)
	elif pyautogui.pixel(400, 700)[0] == 0:
		click(400, 700)
	elif pyautogui.pixel(450,700)[0] == 0:
		click(450, 700)


